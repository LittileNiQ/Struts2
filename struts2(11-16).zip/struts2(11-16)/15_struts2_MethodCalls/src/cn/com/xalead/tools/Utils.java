package cn.com.xalead.tools;

public class Utils {  
   public static String toUpperCase(String str){	   
	return str.toUpperCase();   
   }
   public static String toLowerCase(String str)
   {
	return str.toLowerCase();   
   }
   public String substring(String str,int start,int end){
	   
	   return str.substring(start,end);	   
   }
}
