package cn.com.xalead.action;

import java.util.Date;

import org.apache.struts2.ServletActionContext;

import cn.com.xalead.dao.UserManager;
import cn.com.xalead.entity.User;

import com.opensymphony.xwork2.ActionContext;

public class UserAction {
    private User user;
	public String query(){
	   return "success";
    }
	
	public String addInput(){	
		return "add_input";
	}
    
    public String add(){
    	new UserManager().add(user);
    	return "add_success";
    }
    
    public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String delete(){
       	return "delete_success";
    }
    
    public String updateInput(){
    	return "update_input";
    }
    
    public String update(){	
    	return "update_success";
    }
    
}
