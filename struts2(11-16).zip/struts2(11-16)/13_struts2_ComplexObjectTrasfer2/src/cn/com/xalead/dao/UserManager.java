package cn.com.xalead.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cn.com.xalead.entity.User;
import cn.com.xalead.tool.DB;

public class UserManager {
	public void add(User user) {
		Connection conn = DB.getConnection();
		PreparedStatement prst = null;
		String sql = "INSERT INTO user(id,username,password,sex,age) VALUES(?,?,?,?,?)";
		try {
			prst = conn.prepareStatement(sql);
			prst.setInt(1, user.getId());
			prst.setString(2, user.getUsername());
			prst.setString(3, user.getPassword());
			prst.setString(4, String.valueOf(user.getSex()));
			prst.setInt(5, user.getAge());

			prst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.closeConn(conn);
		}
	}

	public void delete(int userId) {
	}

	public void update(User user) {

	}

	public User findById(int userId) {
		User user = null;
		Connection conn = DB.getConnection();
		PreparedStatement prst = null;
		ResultSet rs=null;
		String sql = "select * from user where id=?";
		try {
			prst = conn.prepareStatement(sql);
			prst.setInt(1, userId);
		    rs=prst.executeQuery();
		    if(!rs.next())
		    {
		    	throw new SQLException("û���ҵ���¼��");
		    }
			user=new User();
			user.setId(userId);
		    user.setUsername(rs.getString("username"));
		    user.setPassword(rs.getString("password"));
		    user.setAge(rs.getInt("age"));
		    user.setSex(rs.getString("sex").charAt(0));
		    
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DB.closeConn(conn);
		}

		return user;
	}
}
