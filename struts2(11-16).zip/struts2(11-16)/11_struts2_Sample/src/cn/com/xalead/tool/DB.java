package cn.com.xalead.tool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Driver;
public class DB {
	
     public static Connection getConnection(){
    	 Connection conn=null;
    	 String url="jdbc:mysql://localhost:3306/test";
    	 String driverClass="com.mysql.jdbc.Driver";
    	 String username="root";
    	 String password="123456";
    	try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url,username,password);
		} catch (Exception e) {
			e.printStackTrace();
		}
    
		return conn; 
     }
     public static void closeConn(Connection conn){
    	 if(conn!=null){
    		 try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	 }
     }
}
