package test;

import ognl.Ognl;
import ognl.OgnlException;
import junit.framework.TestCase;
import cn.com.xalead.entity.Address;
import cn.com.xalead.entity.Contact;
import cn.com.xalead.entity.User;

public class OGNLTest extends TestCase{
	/*
	 * ���Ը�����Root�ĸ�����
	 * 
	 */
	 public void test(){
		User user=new User();
		user.setUsername("����");
		user.setPassword("111");
		user.setSex('��');
		user.setAge(20);
		Address address=new Address();
		address.setBusinessAddress("����");
		address.setHomeAddress("����");
		user.setAddress(address);
		Contact contact =new Contact();
		contact.setPhone("11111111111");
		contact.setQq("2080252788");
		contact.setTel("4255202");
		address.setContact(contact);
		
		try {
			String phone=(String)Ognl.getValue("address.contact.phone",user);
	        System.out.print(phone);
	        Ognl.setValue("address.contact.phone", user,"1111111"); 
	        System.out.println(user.getAddress().getContact().getPhone());
		} catch (OgnlException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	 }
	 
	 
	 public void test2(){
			User user=new User();
			user.setUsername("����");
			user.setPassword("111");
			user.setSex('��');
			user.setAge(20);
			Address address=new Address();
			address.setBusinessAddress("����");
			address.setHomeAddress("����");
			user.setAddress(address);
			Contact contact =new Contact();
			contact.setPhone("11111111111");
			contact.setQq("2080252788");
			contact.setTel("4255202");
			address.setContact(contact);
			
			try {
				String phone=(String)Ognl.getValue("#root.address.contact.phone",user);
		        System.out.print(phone);
		        Ognl.setValue("address.contact.phone", user,"1111111"); 
		        System.out.println(user.getAddress().getContact().getPhone());
			} catch (OgnlException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
	 
	 public void test3(){
			User user=new User();
			user.setUsername("����");
			user.setPassword("111");
			user.setSex('��');
			user.setAge(20);
			Address address=new Address();
			address.setBusinessAddress("����");
			address.setHomeAddress("����");
			user.setAddress(address);
			Contact contact =new Contact();
			contact.setPhone("11111111111");
			contact.setQq("2080252788");
			contact.setTel("4255202");
			address.setContact(contact);
			
			try {
				String phone=(String)Ognl.getValue("#root.contact.phone",address);
		        System.out.print(phone);
		        Ognl.setValue("#root.contact.phone", address,"1111111"); 
		        System.out.println(user.getAddress().getContact().getPhone());
			} catch (OgnlException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		 }
}
