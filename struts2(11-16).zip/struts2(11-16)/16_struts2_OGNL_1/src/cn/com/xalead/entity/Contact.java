package cn.com.xalead.entity;

public class Contact {
   private String qq;
   private String tel;
   private String phone;
public String getQq() {
	return qq;
}
public void setQq(String qq) {
	this.qq = qq;
}
public String getTel() {
	return tel;
}
public void setTel(String tel) {
	this.tel = tel;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
   
}
