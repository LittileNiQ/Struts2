package cn.com.xalead.action;

import java.util.Date;

import com.opensymphony.xwork2.ActionContext;

public class UserAction {
    private String username;
    private String password;
    private Integer age;
    private Long lng;
    private boolean bln;
    private double dbl;
    private char sex;
    
    
    public char getSex() {
		return sex;
	}

	public void setSex(char sex) {
		this.sex = sex;
	}

	public String test(){
       System.out.print(this);
       if(!("zhangsan".equals(username) && "111".equals(password) ))
       {
    	   return "form";
       }
	   return "success";
    }
    
    public String add(){
    	Date add=new Date();
    	return "success";
    }
    
    public String delete(){
    	Date del=new Date();
    	
    	return "success";
    }
    
    public String update(){
    	username="����";
    	password="111";
    	sex='��';
    	Date modify=new Date();
    	ActionContext.getContext().put("modify", modify);
    	ActionContext.getContext().put("name","����" );
    	ActionContext.getContext().put("username", "����");
    	return "update_success";
    }
    
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Long getLng() {
		return lng;
	}
	public void setLng(Long lng) {
		this.lng = lng;
	}
	public boolean isBln() {
		return bln;
	}
	public void setBln(boolean bln) {
		this.bln = bln;
	}
	public double getDbl() {
		return dbl;
	}
	public void setDbl(double dbl) {
		this.dbl = dbl;
	}
}
