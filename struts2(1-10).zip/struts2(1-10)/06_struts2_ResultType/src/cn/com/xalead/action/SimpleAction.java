﻿package cn.com.xalead.action;



  public class SimpleAction {
	private String username;
	private String password;
	
  public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
  public String test(){
	  System.out.println("执行测试方法");
	  return "hello";
  }
  public String addInput(){
	   System.out.println("进入添加页面！");
	  return "add_input";
  }
  
  public String add(){
	 System.out.println("执行添加操作");
	  System.out.println("Password:"+password);
	  System.out.println("UserName:"+username);
	  return "add_success";
  }
  
  public String updateInput(){
	  System.out.println("进入更新页面");
	  return "update_input";
  }
  public String update(){
	  System.out.println("执行更新操作");
	  return "update_success";
  }
  public String delete(){
	 System.out.println("执行删除方法");
	  return "delete_success";
  }
  public String delete_input(){
	  System.out.println("执行删除input方法");
	  return "delete_success";
  }
  public String chainTypeResult(){
	System.out.println("服务器端转发另一个Action方法");
	username="s";
	return "otherAction";
  }
}
