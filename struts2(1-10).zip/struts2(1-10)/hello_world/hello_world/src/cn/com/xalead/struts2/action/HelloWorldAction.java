package cn.com.xalead.struts2.action;

import cn.com.xalead.struts2.model.MessageStore;
 
public class HelloWorldAction  {
 
    private MessageStore messageStore;
     
    public String execute() throws Exception {
         
        messageStore = new MessageStore() ;
        return "success";
    }
 
    public MessageStore getMessageStore() {
        return messageStore;
    }
 
    public void setMessageStore(MessageStore messageStore) {
        this.messageStore = messageStore;
    }
 
}