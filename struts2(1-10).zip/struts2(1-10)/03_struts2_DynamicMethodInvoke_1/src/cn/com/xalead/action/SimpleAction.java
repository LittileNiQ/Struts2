package cn.com.xalead.action;

public class SimpleAction {
	private String username;
	private String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String test() {
		System.out.println("ִ�в��Է���");
		return "hello";
	}

	public String addInput() {
		System.out.println("��������ҳ�棡");
		return "add_input";
	}

	public String add() {
		System.out.println("ִ�����Ӳ���");
		System.out.println("Password:" + password);
		System.out.println("UserName:" + username);
		return "add_success";
	}

	public String updateInput() {
		System.out.println("�������ҳ��");
		return "update_input";
	}

	public String update() {
		System.out.println("ִ�и��²���");
		return "update_success";
	}

	public String delete() {
		System.out.println("ִ��ɾ������");
		return "delete_success";
	}
}
