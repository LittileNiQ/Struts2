package cn.com.xalead.interceptor;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class LoginInterceptor extends AbstractInterceptor{
	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
      ActionContext actionContext=invocation.getInvocationContext();
		String result=null;
        if(actionContext.getSession().get("username")==null||"".equals(actionContext.getSession().get("username"))){   
          	ActionContext.getContext().put("loginJsp", "/login.jsp");
            return "login";
    	}else if(actionContext.getSession().get("username").equals("lisi")){
      	  ActionContext.getContext().put("loginJsp", "/IamNotLikeLisi.jsp");    
            return "login";
    	}
     result=invocation.invoke();		
   	 return result;
	}
}