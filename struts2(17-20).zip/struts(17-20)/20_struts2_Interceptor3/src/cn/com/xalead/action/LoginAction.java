package cn.com.xalead.action;

import com.opensymphony.xwork2.ActionContext;

public class LoginAction {
  private String username;
  private String password;
  
  public String login(){
	  if(("zhangsan".equals(username)&&"111".equals(password))
		||("lisi".equals(username)&&"111".equals(password)))
	  { 
		  ActionContext.getContext().getSession().put("username",username);
		  return "success";
	  }
	  return "login";
  }
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
  
}
