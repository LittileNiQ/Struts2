package cn.com.xalead.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;

import cn.com.xalead.dao.UserManager;
import cn.com.xalead.entity.User;
import cn.com.xalead.tools.Utils;

public class UserAction {
    private User user=null;
    private String username;
    private String password;
    
    public String staticCalls(){
//    	if(!("zhangsan".equals(username)&&"111".equals(password))){
//    		return "login";
//    	}
    	username="ZhangSan";
    	password="ABCdeF";
    	user=new User();
    	user.setAge(20);
    	user.setSex('F');
    	return "static";
    }
    
    public String out(String mesg)
    {
    	return "Hello"+mesg;
    }
    
    public Utils getUtils(){
    	return new Utils();
    }
    
    public String getPassword(){
		return password;
	}
    
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String queryAll(){
    	username="����";
    	password="111";
    	List<User> list=new ArrayList<User>();
    	for(int i=0;i<50;i++)
    	{
    		User u=new User();
    		u.setUsername("User_"+i);
    		u.setPassword("pwd_"+i);
    		u.setSex(i%2==0?'M':'F');
    		u.setAge(new Random().nextInt(100));
    		list.add(u);	
    	}
    	ActionContext.getContext().put("list", list);   	
		return "list";
    }
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String query(){
		if(user.getId()!=0)
		{
			User u= new UserManager().findById(user.getId());
			if(u!=null){
			//	ActionContext.getContext().put("user", u);
				ServletActionContext.getRequest().getSession().setAttribute("user", u);
			//	ActionContext.getContext().getSession().put("user",u);
			}
		}
	   return "success";
    }
	
	public String addInput(){	
		return "add_input";
	}
    
    public String add(){
    	new UserManager().add(user);
    	return "add_success";
    }
    
    public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String delete(){
       	return "delete_success";
    }
    
    public String updateInput(){
    	return "update_input";
    }
    
    public String update(){	
    	return "update_success";
    }
}
