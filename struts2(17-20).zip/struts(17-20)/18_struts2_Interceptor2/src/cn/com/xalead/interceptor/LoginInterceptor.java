package cn.com.xalead.interceptor;

import cn.com.xalead.action.UserAction;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.ActionProxy;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class LoginInterceptor extends AbstractInterceptor {

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		UserAction action=(UserAction) invocation.getAction();
//		ActionProxy proxy=invocation.getProxy();
        String result=null;
      
        if(!("zhangsan".equals(action.getUsername())&&"111".equals(action.getPassword()))){
    		return "login";
    	}
        result=invocation.invoke();
		
		return result;
	}

}
